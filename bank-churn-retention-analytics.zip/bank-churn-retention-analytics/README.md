# Customer Engagement & Product Utilization Analytics for Retention Strategy

A behavioral analytics project analyzing 10,000 European bank customers to understand what actually drives customer churn — engagement and product usage, not just demographics or balance.

**Domain:** Finance Analytics (Banking)
**Dataset:** European Bank customer dataset (10,000 records)
**Status:** Complete

🔗 **Live App:** [add your Streamlit Community Cloud link here after deployment]
📊 **Power BI Dashboard:** `Interactive_Dashboard.html` (open directly in any browser) or publish `PowerBI_Data_Model.xlsx` via the included build guide

---

## Problem Statement

Banks often have data on customer engagement and product usage but lack quantitative insight into which behaviors actually drive retention — leading to generic retention strategies that are misaligned with real customer behavior. This project asks three questions directly from the data:

- Does engagement (activity status) predict churn better than financial strength?
- Does holding more products reduce churn?
- Can we identify high-value customers who are silently at risk of leaving?

## Key Finding

**Engagement beats balance.** Inactive, high-balance customers churn at **32.3%** — more than 3x the rate of actively engaged customers (**9.7%**). A high account balance does not signal a loyal customer; whether they actually use the bank's services does.

## Repository Structure

```
.
├── README.md                          # this file
├── data/
│   ├── European_Bank.csv              # original raw dataset
│   └── European_Bank_engineered.csv   # dataset with engineered features
├── analysis/
│   └── feature_engineering.py         # engagement/product/relationship feature logic
├── model/
│   ├── churn_model.joblib             # trained Gradient Boosting model
│   ├── feature_columns.joblib         # feature order expected by the model
│   └── results.json                   # full evaluation metrics for all models tried
├── app/
│   ├── app.py                         # Streamlit dashboard (5 modules)
│   ├── feature_engineering.py         # (copy, used by the app)
│   ├── European_Bank.csv              # (copy, used by the app)
│   ├── model/                         # (copy, used by the app)
│   └── requirements.txt
├── powerbi/
│   ├── Interactive_Dashboard.html     # standalone interactive dashboard (no install needed)
│   ├── PowerBI_Data_Model.xlsx        # cleaned data ready for Power BI import
│   ├── DAX_Measures_Library.txt       # all 20 DAX measures, ready to paste in
│   └── PowerBI_Build_Guide.docx       # step-by-step Power BI build instructions
└── docs/
    ├── Research_Paper.docx            # full EDA, methodology, KPIs, model results, recommendations (charts embedded)
    └── Executive_Summary.docx         # plain-language summary for non-technical stakeholders
```

> Note: the EDA chart-generation and model-training scripts used to build this project aren't included as standalone files in this package — only their outputs are (the charts are embedded in Research_Paper.docx, and the trained model is in `model/`). If you need the original scripts too, ask and they can be regenerated.

## Methodology

1. **Data Ingestion & Validation** — schema checks, binary field consistency, duplicate/missing-value checks
2. **Engagement Classification** — segments customers into Active Engaged / Active Low-Product / Inactive Disengaged / Inactive High-Balance
3. **Product Utilization Analysis** — churn by product count and depth, single vs multi-product retention
4. **Financial Commitment vs Engagement Analysis** — balance × activity cross-analysis, at-risk premium customer detection
5. **Retention Strength Assessment** — composite Relationship Strength Index (0–4), "sticky customer" identification

## Key Performance Indicators

| KPI | Result |
|---|---|
| Engagement Retention Ratio | Inactive churn (26.9%) is 1.88x active churn (14.3%) |
| Product Depth Index | Lowest churn at 2 products (7.6%); highest at 3–4 products (82.7% / 100%, small sample) |
| High-Balance Disengagement Rate | 32.3% churn among high-balance, inactive customers |
| Credit Card Stickiness Score | Negligible effect (20.2% vs 20.8%) |
| Relationship Strength Index | Churn falls from 33.1% (score 0) to 9.3% (score 4) |

## Model Performance

Five models were trained and compared (Logistic Regression, Random Forest, XGBoost, LightGBM, Gradient Boosting, and a voting ensemble). **Gradient Boosting** was selected as the final model:

| Metric | Score |
|---|---|
| Test Accuracy | 87.1% |
| ROC-AUC | 0.871 |
| 5-Fold CV Accuracy | 86.5% ± 0.5% |
| Precision (churn class) | 0.78 |
| Recall (churn class) | 0.50 |

**Note on accuracy:** The project brief targeted 90% accuracy. On this dataset, that figure is not achievable without data leakage or test-set overfitting — 87.1% is consistent with the best publicly documented results on this dataset and was validated with cross-validation rather than a single lucky split. See `Research_Paper.docx` Section 8.2 for the full discussion.

## How to Run the Streamlit App Locally

```bash
cd app
pip install -r requirements.txt
streamlit run app.py
```

Opens at `http://localhost:8501`. Five modules: Engagement vs Churn Overview, Product Utilization Impact Analysis, High-Value Disengaged Customer Detector, Retention Strength Scoring, and an individual Churn Risk Predictor powered by the trained model.

## How to Use the Power BI Dashboard

- **Quick option:** open `powerbi/Interactive_Dashboard.html` in any browser — no installation required, fully interactive with live filtering.
- **Full Power BI option:** follow `powerbi/PowerBI_Build_Guide.docx` using `PowerBI_Data_Model.xlsx` and `DAX_Measures_Library.txt` (~30–45 min build).

## Deliverables Checklist

- [x] Research paper (EDA, insights, recommendations)
- [x] Streamlit dashboard (live analytics)
- [x] Executive summary for stakeholders
- [x] Interactive Power BI–style dashboard

## Tech Stack

Python · pandas · scikit-learn · XGBoost · LightGBM · Streamlit · Plotly · Power BI / DAX · Chart.js

## Author

[Your Name] — Data Science Intern
[Your program / institution, e.g. Unified Mentor]
