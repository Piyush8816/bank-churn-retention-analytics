# Customer Engagement & Retention Analytics — Streamlit App

## Setup

```bash
pip install -r requirements.txt
streamlit run app.py
```

The app will open at http://localhost:8501

## Contents
- `app.py` — main Streamlit application
- `feature_engineering.py` — engagement/product/relationship feature engineering logic
- `European_Bank.csv` — source dataset
- `model/churn_model.joblib` — trained Gradient Boosting churn model
- `model/feature_columns.joblib` — feature column order expected by the model
- `model/results.json` — full model evaluation results

## Modules
1. **Engagement vs Churn Overview** — engagement segment analysis, active vs inactive comparison
2. **Product Utilization Impact Analysis** — churn by product count and depth
3. **High-Value Disengaged Customer Detector** — configurable at-risk customer finder with CSV export
4. **Retention Strength Scoring** — Relationship Strength Index and "sticky customer" analysis
5. **Churn Risk Predictor** — interactive per-customer prediction using the trained ML model
